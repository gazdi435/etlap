let aktivCuccok = { 'gulyas': false, 'gyomulcsleves': false, 'husleves': false, 'palocleves': false, 'raguleves': false};
function nyomasnal(ertek) {
    if (aktivCuccok[ertek] == false) {
        aktivCuccok[ertek] = true;
        document.getElementById(ertek).style.backgroundColor = "rgba(255,255,0,0.4)";
        document.getElementById(ertek).style.border = "3px solid red";
    } else  {
        aktivCuccok[ertek] = false;
        document.getElementById(ertek).style.backgroundColor = "white";
        document.getElementById(ertek).style.border = "3px solid black";
    }

    if  (aktivCuccok['gulyas'] == true || aktivCuccok['gyomulcsleves'] == true || aktivCuccok['husleves'] == true || aktivCuccok['palocleves'] == true || aktivCuccok['raguleves'] == true) {
        document.getElementById('levesek').style.backgroundColor = "rgba(255,255,0,0.4)";
    }

}