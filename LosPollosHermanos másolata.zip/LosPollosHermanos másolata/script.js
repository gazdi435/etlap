function levesek(ertek) {
    document.getElementById(ertek).style.backgroundColor = "rgba(255,255,0,0.4)";
    document.getElementById(ertek).style.border = "3px solid red";
    if (document.getElementById(gulyas).alt == "") {

    }
}