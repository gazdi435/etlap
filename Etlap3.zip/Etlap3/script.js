function rendeles() {
    var x = document.getElementById("form");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
}

function thanks(){
    var div = document.getElementById("thanks").innerHTML = "Köszönjük Rendelését!";
}
