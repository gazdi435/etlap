let aktivCuccok = { 'gulyas': false, 'gyomulcsleves': false, 'husleves': false, 'palocleves': false, 'raguleves': false, 
'gulyasertek': 1000, 'gyomulcslevesertek': 800, 'huslevesertek': 800, 'ragulevesertek': 800};
let osszeg = 0;
function nyomasnal(ertek) {
    if (aktivCuccok[ertek] == false) {
        aktivCuccok[ertek] = true;
        document.getElementById(ertek).style.backgroundColor = "rgba(102, 51, 0,0.6)";
        document.getElementById(ertek).style.border = "3px solid rgb(255, 132, 0)";
        document.getElementById(ertek).style.width =
        osszeg = osszeg + aktivCuccok[ertek + "ertek"]
        document.getElementById("osszeg").innerHTML = osszeg
    } else  {
        aktivCuccok[ertek] = false;
        document.getElementById(ertek).style.backgroundColor = "rgba(102, 51, 0,0.0)";
        document.getElementById(ertek).style.border = "rgb(89, 31, 6) solid 2px";
        osszeg = osszeg - aktivCuccok[ertek + "ertek"]
        document.getElementById("osszeg").innerHTML = osszeg
    }

    if  (aktivCuccok['gulyas'] == true || aktivCuccok['gyomulcsleves'] == true || aktivCuccok['husleves'] == true || aktivCuccok['palocleves'] == true || aktivCuccok['raguleves'] == true) {
        document.getElementById('levesek').style.backgroundColor = "rgba(255,255,0,0.4)";
    } else {
        document.getElementById('levesek').style.backgroundColor = "rgba(255,255,0,0.0)";
    }


}